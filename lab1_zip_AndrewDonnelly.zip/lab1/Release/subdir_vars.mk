################################################################################
# Automatically-generated file. Do not edit!
################################################################################

SHELL = cmd.exe

# Add inputs and outputs from these tool invocations to the build variables 
CMD_SRCS += \
../cc3200v1p32.cmd 

C_SRCS += \
../gpio_if.c \
../main.c \
../pin_mux_config.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/startup_ccs.c \
C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.c 

C_DEPS += \
./gpio_if.d \
./main.d \
./pin_mux_config.d \
./startup_ccs.d \
./uart_if.d 

OBJS += \
./gpio_if.obj \
./main.obj \
./pin_mux_config.obj \
./startup_ccs.obj \
./uart_if.obj 

OBJS__QUOTED += \
"gpio_if.obj" \
"main.obj" \
"pin_mux_config.obj" \
"startup_ccs.obj" \
"uart_if.obj" 

C_DEPS__QUOTED += \
"gpio_if.d" \
"main.d" \
"pin_mux_config.d" \
"startup_ccs.d" \
"uart_if.d" 

C_SRCS__QUOTED += \
"../gpio_if.c" \
"../main.c" \
"../pin_mux_config.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/startup_ccs.c" \
"C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.c" 



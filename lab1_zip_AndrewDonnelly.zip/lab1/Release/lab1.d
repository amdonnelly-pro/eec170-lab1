# FIXED

lab1.obj: ../lab1.c
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_map.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_patch.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_memmap.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_common_reg.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_ints.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/uart.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/interrupt.h
lab1.obj: ../pin_mux_config.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/utils.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h
lab1.obj: C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.h

../lab1.c:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_map.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/rom_patch.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_memmap.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_common_reg.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_types.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/inc/hw_ints.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/uart.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/interrupt.h:

../pin_mux_config.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/utils.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/driverlib/prcm.h:

C:/ti/CC3200SDK_1.5.0/cc3200-sdk/example/common/uart_if.h:

